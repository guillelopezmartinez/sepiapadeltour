import { getStore } from "@netlify/blobs";
import { createHash, timingSafeEqual } from "node:crypto";
import { emptyState, sanitize } from "../lib/estado.mjs";

// GET  /api/torneo  -> estado actual (público)
// POST /api/torneo  -> comprueba la contraseña de admin
// PUT  /api/torneo  -> guarda el estado (solo con la contraseña de admin)
export const config = { path: "/api/torneo" };

const HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};
const reply = (body, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: HEADERS });

const digest = (s) => createHash("sha256").update(String(s)).digest();

function isAdmin(req) {
  const expected = process.env.ADMIN_PASSWORD;
  if (!expected) return null; // sin configurar
  const given = req.headers.get("x-admin-password") || "";
  return timingSafeEqual(digest(given), digest(expected));
}

export default async (req) => {
  const store = getStore("torneo");

  if (req.method === "GET") {
    const state = await store.get("estado", { type: "json" });
    return reply(state || emptyState());
  }

  if (req.method === "POST" || req.method === "PUT") {
    const ok = isAdmin(req);
    if (ok === null) return reply({ error: "Falta configurar ADMIN_PASSWORD en Netlify." }, 500);
    if (!ok) return reply({ error: "Contraseña incorrecta." }, 401);

    if (req.method === "POST") return reply({ ok: true });

    try {
      const body = await req.json();
      const state = sanitize(body);
      await store.setJSON("estado", state);
      return reply(state);
    } catch (e) {
      return reply({ error: e.status === 400 ? e.message : "No se pudo guardar." }, e.status || 500);
    }
  }

  return reply({ error: "Método no permitido." }, 405);
};
