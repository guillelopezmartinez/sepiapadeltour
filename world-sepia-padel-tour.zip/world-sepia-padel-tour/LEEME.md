# World Sepia Padel Tour 2026

Web del torneo. Todo el mundo ve la **Clasificación** y las **Jornadas**. El admin entra con una contraseña y ve además la **Fase final** y los campos para registrar cada resultado.

Los datos se guardan en Netlify (Netlify Blobs), así que no hace falta ninguna otra cuenta ni base de datos.

## Qué hay en la carpeta

- `public/index.html` y `public/logo.jpg`: la web.
- `netlify/functions/torneo.mjs`: guarda y devuelve los resultados. Solo guarda si llega la contraseña de admin.
- `netlify/lib/estado.mjs`: comprueba que los datos sean válidos antes de guardarlos.
- `package.json` y `netlify.toml`: configuración.

## Cómo publicarla (con GitHub)

Hay que subirla con GitHub porque la función necesita que Netlify instale una dependencia, y la subida de carpeta arrastrando no hace ese paso.

1. Crea un repositorio nuevo en GitHub (puede ser privado) y sube **todo el contenido de esta carpeta**, respetando las subcarpetas (`public`, `netlify`). En la web de GitHub: *Add file > Upload files* y arrastra las carpetas.
2. En Netlify: *Add new project > Import an existing project > GitHub* y elige ese repositorio. No hace falta cambiar nada; coge solo la configuración de `netlify.toml`.
3. Cuando termine el primer despliegue, ve a *Project configuration > Environment variables* y crea una variable:
   - Nombre: `ADMIN_PASSWORD`
   - Valor: la contraseña que quieras para el admin.
4. Vuelve a desplegar (*Deploys > Trigger deploy > Deploy project*) para que la función lea la contraseña.
5. Abre la web. Abajo del todo, **Acceso admin**, escribe la contraseña y listo.

Los nombres exactos de los menús de Netlify pueden variar un poco.

## Cómo publicarla (con la línea de comandos)

```
npm install -g netlify-cli
netlify login
netlify init
netlify env:set ADMIN_PASSWORD "tu-contraseña"
netlify deploy --build --prod
```

## Uso

- El admin guarda cada partido con los sets de cada pareja, por ejemplo 2 y 1. La web decide quién gana.
- Victoria = 3 puntos. Desempata la diferencia de sets y después los sets a favor.
- Cuando se juegan los 21 partidos, el admin puede registrar las semifinales y la final.
- Para cambiar la contraseña, cambia la variable `ADMIN_PASSWORD` en Netlify y vuelve a desplegar.
- El navegador del admin recuerda la contraseña. El botón **Salir** la borra de ese navegador.
